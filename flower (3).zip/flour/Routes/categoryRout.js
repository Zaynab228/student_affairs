const express=require('express');
const router=express.Router();
const category=require('../contorller/category')
router.get('/catall',category.allCategory);
//show all
// get by name
router.get('/catget/:id',category.getbyCategoryname);
//create flour
 router.post('/catinsert',category.insertCategry);
// up date last 20
// delet last 10
 router.put('/catupdate/:name',category.update)
 router.delete('/catdelete/:name',category.Delete)
 module.exports=router