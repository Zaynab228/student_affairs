const express=require('express');
const router=express.Router();
const ProductController=require('../contorller/ProductController')
const multer = require('multer');
const FILE_TYPE_MAP = {
  'image/png': 'png',
  'image/jpeg': 'jpeg',
  'image/jpg': 'jpg'
}
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
      const isValid = FILE_TYPE_MAP[file.mimetype];
      let uploadError = new Error('invalid image type');

      if(isValid) {
          uploadError = null
      }
    cb(uploadError, 'public/uploads')
  },
  filename: function (req, file, cb) {
      
    const fileName = file.originalname.split(' ').join('-');
    const extension = FILE_TYPE_MAP[file.mimetype];
    cb(null, `${fileName}-${Date.now()}.${extension}`)
  }
})
const uploadOptions = multer({ storage: storage })
router.post('/insert',uploadOptions.single('image'), ProductController.putnew);

 router.get('/allp',ProductController.getall);
 router.get('/get/:id',ProductController.getbyid);
 router.get('/productbycategoy/:categories',ProductController.getbyCategory)
 router.get('/count',ProductController.count)
 router.get('/featured/:count',ProductController.countfeatured)
// delete fnction
//update   function

// up date last 20
// delet last 10
 //router.delete('/del/:name',ProductController.Del)
// router.put('/update/:name',ProductController.update)
 //router.get('/price/:price',ProductController.price)
// router.get('/season/:season',ProductController.season)
  module.exports=router;