const express=require('express');
const router=express.Router();
const order=require('../contorller/order')

router.post('/order',order.order);
router.get('/allorder',order.getallorder);
router.get(`/getorder/:id`,order.getbyuserid) 
router.delete('/orders/:id',order.DEl) 
router.get('/get/totalsales',order.totalSales)
router.get(`/getByUserId/:userid`,order.getbyuserid)
module.exports=router