const express=require('express')
const router=express.Router();
const usercontroller=require('../contorller/usercontroller')
router.post('/register',usercontroller.signup)
router.post('/login',usercontroller.login)
module.exports=router;