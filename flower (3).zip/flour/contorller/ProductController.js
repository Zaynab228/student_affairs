const Product=require('../Models/productsmodel')
const Category=require("../Models/category")

   let getall=async (_req,res)=>{
    let productlist=await Product.find();
       if(!productlist){
        res.status(404).send("there no prodycts")
       }
       res.send(productlist)
   }
   let getbyid=async (req,res)=>{
    let id=req.params.id;
    let product=await Product.findById(id).select('name description -_id').populate('category');
      
       res.send(product)
   }
   //const uploadOptions = multer({ storage: storage })

   let putnew= async function gett(req, res) {
      console.log(req.body)
    const category = await Category.findById(req.body.category);
    if (!category) return res.status(400).send('Invalid Category');
    const file = req.file;
    if(!file) return res.status(400).send('No image in the request')
    const fileName = file.filename
    const basePath = `${req.protocol}://${req.get('host')}/public/uploads/`;
    let product = new Product({
        name: req.body.name,
        description: req.body.description,
        richDescription: req.body.richDescription,
        image:`${basePath}${fileName}`,
        brand: req.body.brand,
        price: req.body.price,
        category: req.body.category,
        countInStock: req.body.countInStock,
        rating: req.body.rating,
        numReviews: req.body.numReviews,
        IsFeatured: req.body.isFeatured
    });
    console.log(product);
    product = await product.save();

    if (!product)
        return res.status(500).send('The product cannot be created');

    res.send(product);
}
const getbyCategory= async (req, res) =>{
    // localhost:3000/api/v1/products?categories=2342342,234234
    let filter = {};
    if(req.query.categories)
    {
         filter = {category: req.query.categories.split(',')}
    }

    const productList = await Product.find(filter).populate('category');

    if(!productList) {
        res.status(500).json({success: false})
    } 
    res.send(productList);
}
let countfeatured= async (req, res) =>{
    const count = req.params.count ? req.params.count : 0
    const products = await Product.find({isFeatured: false}).limit(+count);

    if(!products) {
        res.status(500).json({success: false})
    } 
    res.send(products);
}

let count= async (req, res) =>{
    let count=await Product.countDocuments()
    if(!count) {
        res.status(500).json({success: false})
    } 
    res.send({"the count is":count})
}

module.exports={putnew,getall,getbyid,getbyCategory,count,countfeatured}
      
    

