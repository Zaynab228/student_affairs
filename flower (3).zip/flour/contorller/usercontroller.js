const User = require('../Models/usermodel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
; // Assuming User model is defined in a separate file

const signup= async (req, res) => {
  console.log(req.body)
    try {
      const hashedPassword = bcrypt.hashSync(req.body.password, 10);
      const user = new User({
        name: req.body.name,
        email: req.body.email,
        passwordHash: hashedPassword,
        phone: req.body.phone,
        isAdmin: req.body.isAdmin,
        street: req.body.street,
        apartment: req.body.apartment,
        zip: req.body.zip,
        city: req.body.city,
        country: req.body.country
      });
      const u=await User.find()
      console.log(u)
      await user.save();
      console.log("jrgrt")

      res.send(user);
     
    } catch (error) {
      res.status(400).send(error.message);
    }
  }
  
// Login route
//app.post('/login',
const login= async (req, res) => {
    const { name, passwordHash} = req.body;
    //try {
        // Find the user by username
        const user = await User.findOne({ name });
        console.log(user)
        if (!user) {
            return res.status(401).json({ error: "Invalid username or password" });
        }
        // Compare the password
        if(user.passwordHash===passwordHash){
        res.json({message:"done"})
        
        }   else{
            res.json({message:"invalid"})

        }
    }
    // router.get(`/`,
    const alluser= async (req, res) =>{
      const userList = await User.find().select('-passwordHash');
  
      if(!userList) {
          res.status(500).json({success: false})
      } 
      res.send(userList);
  }
  
  // router.get('/:id',
  const getbyname= async(req,res)=>{
      const user = await User.findById(req.params.name).select('-passwordHash');
      if(!user) {
          res.status(500).json({message: 'The user with the given ID was not found.'})
      } 
      res.status(200).send(user);
  }
module.exports={
    login,
    signup,
    alluser,
    getbyname,
}




