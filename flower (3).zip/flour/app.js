const express = require('express');
const app = express();
 app.use(express.json())

       const ProductRouter=require('./Routes/ProductRout')
       const userRouter=require('./Routes/userRouter');
       const categoryrout=require('./Routes/categoryRout')
       const order=require('./Routes/order')
        app.use(ProductRouter)
        app.use(userRouter)
        app.use(order)
        app.use(categoryrout)
        module.exports=app